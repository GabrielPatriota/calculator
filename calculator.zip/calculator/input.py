inputOne = int(input("Insert a number:\n"))
inputSign = input("What do you want to do?\n")
inputTwo = int(input("Insert another number:\n"))